import github from "./img/github.svg";
import globe from "./img/globe.svg";
import google from "./img/google.svg";

export { github, globe, google };
