import { handlers } from "@/lib/utils/auth";
export const { GET, POST } = handlers;
