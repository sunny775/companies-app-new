import { Custom404 } from "@/components/views/Custom404/Custom404";


export default function Page(){

    return <Custom404 />
}