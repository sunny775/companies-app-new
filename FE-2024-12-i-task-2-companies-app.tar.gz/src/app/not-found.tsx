import { Custom404 } from "@/components/ui/views/Custom404/Custom404";

export default function Page() {
  return <Custom404 />;
}
