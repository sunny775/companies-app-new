export const initialCompanyIds = [
  "f5bdf1a5-8c93-4f75-852f-bdda7c60bfba",
  "77f83669-388c-4d36-8cb5-768a53f9cbd7",
  "4ff0d5d0-86e7-4c3d-864f-83cf588873c5",
  "3b10187d-aec8-486e-b894-a4081c16f8a8",
  "fdcfa502-2f11-4bcf-b23c-3a5f60d28980",
  "6778f417-4641-4421-bb45-2ed9a8766a1e",
  "fb801c8c-9ec4-4ab7-aa50-a0dde2df333e",
  "8d057363-911e-4ac8-bbea-278080bf4277",
  "6835858d-59b4-46af-8cc6-82785a5d3c82",
  "7c794e19-6f30-463b-bba2-7aa91cb6d275",
];
