(()=>{var e={};e.id=446,e.ids=[446],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},12907:(e,r,t)=>{"use strict";e.exports=t(65239).vendored["react-rsc"].ReactServerDOMWebpackServerEdge},13733:(e,r,t)=>{"use strict";t.d(r,{Jj:()=>n,NP:()=>o});var s=t(80724);let a=(0,s.J1)`
  fragment CompanyFeilds on Company {
    id
    legalName
    stateOfIncorporation
    industry
    totalNumberOfEmployees
    numberOfFullTimeEmployees
    numberOfPartTimeEmployees
    website
    linkedInCompanyPage
    facebookCompanyPage
    otherInformation
    primaryContactPerson {
      firstName
      lastName
      email
      phone
    }
    logoS3Key
    phone
    fax
    email
    registeredAddress {
      country
      state
      city
      street
      zipCode
    }
    mailingAddress {
      country
      state
      city
      street
      zipCode
    }
  }
`,o=(0,s.J1)`
  query GetCompany($id: String!) {
    company: getCompany(id: $id) {
      ...CompanyFeilds
    }
  }
  ${a}
`;(0,s.J1)`
  query GetCompanyIds {
    companyIds @client
  }
`,(0,s.J1)`
  query GetSignedUploadUrl($input: SignedFileUploadInput!) {
    signedUploadUrl: getSignedUploadUrl(input: $input) {
      url
      key
    }
  }
`;let n=(0,s.J1)`
  query GetSignedDownloadUrl($s3Key: String!) {
    signedDownloadUrl: getSignedDownloadUrl(s3Key: $s3Key) {
      url
      key
    }
  }
`},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},43210:(e,r,t)=>{"use strict";e.exports=t(94041).vendored["react-ssr"].React},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},60080:(e,r,t)=>{Promise.resolve().then(t.bind(t,40539))},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},75718:(e,r,t)=>{"use strict";t.r(r),t.d(r,{patchFetch:()=>f,routeModule:()=>m,serverHooks:()=>x,workAsyncStorage:()=>g,workUnitAsyncStorage:()=>y});var s={};t.r(s),t.d(s,{GET:()=>l});var a=t(96559),o=t(48088),n=t(37719),i=t(13733),p=t(13437),u=t(95877),d=t(32190);async function c(e){try{let{data:r,loading:t}=await (0,u.KU)().query({query:i.Jj,variables:{s3Key:e}});return{data:r.signedDownloadUrl,loading:t}}catch(r){let e;return{error:(e="An unexpected error occurred.",r instanceof p.K4?r.graphQLErrors?.length?e=r.graphQLErrors.map(e=>e.message).join(", "):r.networkError&&(e="Network error: "+r.networkError.message):r instanceof Error&&(e=r.message),Error(e))}}}async function l(e,{params:r}){let{s3Key:t}=await r;try{let e=await c(t);if(e.error)return d.NextResponse.json({error:e.error},{status:500});if(!e.data)return d.NextResponse.json({error:"No URL returned"},{status:404});let r=await fetch(e.data.url);if(!r.ok)return d.NextResponse.json({error:`Failed to fetch image: ${r.status} ${r.statusText}`},{status:r.status});let s=await r.arrayBuffer(),a=r.headers.get("content-type")||"image/jpeg";return new d.NextResponse(s,{headers:{"Content-Type":a}})}catch(e){return console.error("Error processing image:",e),d.NextResponse.json({error:"Failed to process image"},{status:500})}}let m=new a.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/s3-image/[s3Key]/route",pathname:"/api/s3-image/[s3Key]",filename:"route",bundlePath:"app/api/s3-image/[s3Key]/route"},resolvedPagePath:"/Users/sonnie-dev/src/esa/companies-app-new/src/app/api/s3-image/[s3Key]/route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:g,workUnitAsyncStorage:y,serverHooks:x}=m;function f(){return(0,n.patchFetch)({workAsyncStorage:g,workUnitAsyncStorage:y})}},84297:e=>{"use strict";e.exports=require("async_hooks")},94041:(e,r,t)=>{"use strict";e.exports=t(10846)},94928:(e,r,t)=>{Promise.resolve().then(t.bind(t,193))},95877:(e,r,t)=>{"use strict";t.d(r,{KF:()=>l,KU:()=>d});var s=t(33878),a=t(23894),o=t(1034),n=t(39798);let i=(0,o.b)(),p=new s.P({uri:"https://be2-fe-task-us-east-1-staging.dcsdevelopment.me/graphql"}),u=(0,a.H)([i,p]),{getClient:d,query:c,PreloadQuery:l}=(0,n.sH)(()=>new n.Ri({cache:new n.D9,link:u,devtools:{enabled:!0}}))},96559:(e,r,t)=>{"use strict";e.exports=t(44870)}};var r=require("../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),s=r.X(0,[447,190,575],()=>t(75718));module.exports=s})();