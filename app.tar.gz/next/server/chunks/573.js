"use strict";exports.id=573,exports.ids=[573],exports.modules={9403:(e,t,a)=>{a.d(t,{S:()=>l,X:()=>o});var r=a(51890),n=a(41067);let o=(0,r.J1)`
  mutation CreateCompany($input: UpdateCompanyInput!) {
    createCompany(input: $input) {
      company {
        ...CompanyFeilds
      }
    }
  }
  ${n.IQ}
`,l=(0,r.J1)`
  mutation UpdateCompany($companyId: ID!, $input: UpdateCompanyInput!) {
    updateCompany(companyId: $companyId, input: $input) {
      company {
        id
        logoS3Key
      }
    }
  }
`},10775:(e,t,a)=>{a.d(t,{A:()=>i});var r=a(60687),n=a(7766),o=a(11860),l=a(29559),s=a(39481);let d=(0,a(81990).tv)({base:"flex relative font-sans text-base font-regular px-4 py-4 rounded-lg border",slots:{action:"!absolute top-2 right-3"},variants:{variant:{default:"bg-gray-50 dark:bg-surface border-0",success:"bg-green-500/5 border-green-500/15 text-green-700 dark:text-green-400 shadow-green-500/10",error:"bg-red-500/5 border-red-500/15 text-red-700 dark:text-red-400 shadow-red-500/10",info:"bg-blue-500/5 border-blue-500/15 text-blue-700 dark:text-blue-400 shadow-blue-500/10"}},defaultVariants:{variant:"default"}}),i=({variant:e,icon:t,open:a,action:i,onClose:c,className:u,children:m,animation:p,...y})=>{let g=d({variant:e}),x=g.base({className:u}),f=g.action(),b={duration:400,mount:"opacity-100 scale-100",unmount:"opacity-0 scale-115",...p};return(0,r.jsx)(s.A,{show:!!a,...b,children:(0,r.jsxs)("div",{...y,role:"alert",className:x,children:[!!t&&(0,r.jsx)("div",{className:"shrink-0",children:t}),(0,r.jsx)("div",{className:(0,n.A)("mr-12",{"ml-3":!!t}),children:m}),c&&!i&&(0,r.jsx)(l.Ay,{onClick:c,size:"sm",variant:e,className:f,title:"alert close button",children:(0,r.jsx)(o.A,{className:"size-5"})}),i||null]})})}},41067:(e,t,a)=>{a.d(t,{IQ:()=>n,NP:()=>o,dB:()=>l});var r=a(51890);let n=(0,r.J1)`
  fragment CompanyFeilds on Company {
    id
    legalName
    stateOfIncorporation
    industry
    totalNumberOfEmployees
    numberOfFullTimeEmployees
    numberOfPartTimeEmployees
    website
    linkedInCompanyPage
    facebookCompanyPage
    otherInformation
    primaryContactPerson {
      firstName
      lastName
      email
      phone
    }
    logoS3Key
    phone
    fax
    email
    registeredAddress {
      country
      state
      city
      street
      zipCode
    }
    mailingAddress {
      country
      state
      city
      street
      zipCode
    }
  }
`,o=(0,r.J1)`
  query GetCompany($id: String!) {
    company: getCompany(id: $id) {
      ...CompanyFeilds
    }
  }
  ${n}
`,l=e=>(0,r.J1)`
  query GetCompanies {
    ${e.map((e,t)=>`
        company${t}: getCompany(id: "${e}") {
          ...CompanyFeilds
        }
      `).join("\n")}
  }
  ${n}
`;(0,r.J1)`
  query GetCompanyIds {
    companyIds @client
  }
`,(0,r.J1)`
  query GetSignedUploadUrl($input: SignedFileUploadInput!) {
    signedUploadUrl: getSignedUploadUrl(input: $input) {
      url
      key
    }
  }
`,(0,r.J1)`
  query GetSignedDownloadUrl($s3Key: String!) {
    signedDownloadUrl: getSignedDownloadUrl(s3Key: $s3Key) {
      url
      key
    }
  }
`},43872:(e,t,a)=>{a.r(t),a.d(t,{"007df04a3981b11b767abac668ada356e72e469aeb":()=>r.r,"4004704a4322a5653646d7bbeb496a69bfbb3f47b1":()=>v,"400df766daf510d6a11795d882b1cd8e56931c2b3d":()=>w});var r=a(48065),n=a(91199);a(42087);var o=a(10796);let l=(0,o.J1)`
  fragment CompanyFeilds on Company {
    id
    legalName
    stateOfIncorporation
    industry
    totalNumberOfEmployees
    numberOfFullTimeEmployees
    numberOfPartTimeEmployees
    website
    linkedInCompanyPage
    facebookCompanyPage
    otherInformation
    primaryContactPerson {
      firstName
      lastName
      email
      phone
    }
    logoS3Key
    phone
    fax
    email
    registeredAddress {
      country
      state
      city
      street
      zipCode
    }
    mailingAddress {
      country
      state
      city
      street
      zipCode
    }
  }
`;(0,o.J1)`
  query GetCompany($id: String!) {
    company: getCompany(id: $id) {
      ...CompanyFeilds
    }
  }
  ${l}
`,(0,o.J1)`
  query GetCompanyIds {
    companyIds @client
  }
`;let s=(0,o.J1)`
  query GetSignedUploadUrl($input: SignedFileUploadInput!) {
    signedUploadUrl: getSignedUploadUrl(input: $input) {
      url
      key
    }
  }
`;(0,o.J1)`
  query GetSignedDownloadUrl($s3Key: String!) {
    signedDownloadUrl: getSignedDownloadUrl(s3Key: $s3Key) {
      url
      key
    }
  }
`;var d=a(88706);function i(e){let t="An unexpected error occurred.";return e instanceof d.K4?e.graphQLErrors?.length?t=e.graphQLErrors.map(e=>e.message).join(", "):e.networkError&&(t="Network error: "+e.networkError.message):e instanceof Error&&(t=e.message),Error(t)}var c=a(81493),u=a(54595),m=a(67641),p=a(23309);let y=(0,m.b)(),g=new c.P({uri:"https://be2-fe-task-us-east-1-staging.dcsdevelopment.me/graphql"}),x=(0,u.H)([y,g]),{getClient:f,query:b,PreloadQuery:h}=(0,p.sH)(()=>new p.Ri({cache:new p.D9,link:x,devtools:{enabled:!0}}));async function v(e){try{let{data:t,loading:a}=await f().query({query:s,variables:{input:e}});return{data:t.signedUploadUrl,loading:a}}catch(e){return{error:i(e)}}}async function w(e){try{let{data:t,error:a}=await v({fileName:e.name,contentType:e.type});if(a)return{error:a};if(!t.url)return{error:Error("Invalid server response. Please try again.")};let r=await fetch(t.url,{method:"PUT",body:e,headers:{"Content-Type":e.type}});if(!r.ok)throw Error(`Upload failed with status: ${r.status}`);return{data:{s3Key:t.key}}}catch(e){return console.error("Error uploading file to S3:",e),{error:i(e)}}}(0,a(33331).D)([v,w]),(0,n.A)(v,"4004704a4322a5653646d7bbeb496a69bfbb3f47b1",null),(0,n.A)(w,"400df766daf510d6a11795d882b1cd8e56931c2b3d",null)},46931:(e,t,a)=>{a.d(t,{A:()=>u});var r=a(60687),n=a(10083),o=a(43210),l=a(29559);let s=e=>{if(0===e)return"0 Bytes";let t=Math.floor(Math.log(e)/Math.log(1024));return parseFloat((e/Math.pow(1024,t)).toFixed(2))+" "+["Bytes","KB","MB"][t]};var d=a(11860),i=a(30474);function c({image:e,setImagePreview:t}){return!!e&&(0,r.jsxs)("div",{className:"flex flex-col items-center justify-center mt-4 mb-8 ",children:[(0,r.jsxs)("div",{className:"relative max-w-60 bg-surface-2 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-200",children:[(0,r.jsx)(i.default,{src:e.url,alt:e.name,width:400,height:400,className:"w-full object-cover"}),(0,r.jsx)(l.Ay,{type:"button",onClick:()=>t(null),variant:"error",size:"sm",className:"absolute top-2 right-2",children:(0,r.jsx)(d.A,{className:"h-4 w-4"})})]}),(0,r.jsxs)("div",{className:"p-3",children:[(0,r.jsx)("p",{className:"text-sm font-medium truncate",children:e.name}),(0,r.jsx)("p",{className:"text-xs text-muted",children:s(e.size)})]})]})}function u({onSubmit:e,children:t,defaultValue:a}){let[l,s]=(0,o.useState)(a),[d,i]=(0,o.useState)(null),u=(0,o.useRef)(null),m=()=>{s(null),d&&(i(null),URL.revokeObjectURL(d.url)),u.current&&(u.current.value="")};return(0,r.jsxs)("form",{onSubmit:function(t){if(t.preventDefault(),console.log(l),!l){alert("No Files selected");return}e(l)},children:[(0,r.jsxs)("div",{className:"col-span-full",children:[(0,r.jsx)("label",{htmlFor:"company-logo",className:"block text-lg font-semibold uppercase my-8",children:"Company Logo"}),(0,r.jsx)("div",{onClick:()=>{u.current&&(u.current.click(),console.log(a))},className:"mt-2 flex justify-center rounded-lg border border-dashed border-gray-900/25 dark:border-gray-600/30 px-6 py-10",children:(0,r.jsxs)("div",{className:"text-center",children:[(0,r.jsx)(n.A,{"aria-hidden":"true",className:"mx-auto size-12 text-gray-300 dark:text-gray-600"}),(0,r.jsxs)("div",{className:"mt-4 text-center text-sm/6 cursor-pointer rounded-md font-semibold text-green-600 dark:text-green-500 hover:opacity-70",children:[(0,r.jsx)("span",{children:l?.[0]?.name||"Upload a file"}),(0,r.jsx)("input",{ref:u,onChange:function(e){let t=e.target.files;if(console.log(t),console.log(e.target.value),t?.length){if(t[0].size<=2097152){s(t);let e=t[0];i({url:URL.createObjectURL(e),name:e.name,size:e.size})}else alert("File too large! Max size is 2MB."),m()}},type:"file",accept:"image/jpeg,image/png",multiple:!1,id:"company-logo",name:"company-logo",className:"sr-only"})]}),(0,r.jsx)("p",{className:"text-xs/5 text-gray-600 dark:text-gray-400",children:"(JPEG and PNG only, 2MB maximum.)"})]})})]}),(0,r.jsx)(c,{image:d,setImagePreview:i}),(0,r.jsx)("div",{className:"flex gap-2 my-4 justify-end",children:t})]})}},51243:(e,t,a)=>{a.d(t,{Ay:()=>x});var r=a(60687),n=a(43210),o=a(81990);let l=(0,n.createContext)(null),s=()=>{let e=(0,n.useContext)(l);if(!e)throw Error("useDialog must be called within a Dialog component");return e},d=(0,o.tv)({base:"relative p-4  antialiased font-sans text-base font-light leading-relaxed max-h-[80vh] overflow-auto",variants:{divider:{true:"border-t border-t-gray-600/20  border-b border-b-gray-600/20"}},defaultVariants:{divider:!1}}),i=(0,o.tv)({base:"flex items-center justify-end shrink-0 flex-wrap p-4"}),c=(0,o.tv)({base:"flex items-center shrink-0 p-4  antialiased font-sans text-2xl font-semibold leading-snug"});(0,o.tv)({base:"flex items-center justify-end shrink-0 flex-wrap p-4"});var u=a(74437),m=a(51215),p=a(39481);let y=(0,o.tv)({base:["relative bg-surface rounded-lg shadow-2xl text-gray-700 dark:text-gray-300 antialiased font-sans text-base font-light leading-relaxed","outline-none p-0 m-auto fixed z-50","top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2","max-w-[90vw] overflow-hidden"],variants:{size:{xs:"w-[calc(100%-24px)] md:w-3/5 lg:w-2/5 2xl:w-1/4 max-w-md",sm:"w-[calc(100%-24px)] md:w-2/3 lg:w-2/4 2xl:w-1/3 max-w-lg",md:"w-[calc(100%-24px)] md:w-3/4 lg:w-3/5 2xl:w-2/5 max-w-xl",lg:"w-[calc(100%-24px)] md:w-5/6 lg:w-3/4 2xl:w-3/5 max-w-2xl",xl:"w-[calc(100%-24px)] md:w-5/6 2xl:w-3/4 max-w-4xl",xxl:"w-[calc(100%-24px)] h-[calc(100%-24px)]"}},defaultVariants:{size:"md"}}),g=(0,o.tv)({base:"fixed inset-0 bg-black/10 backdrop-blur-sm z-40"}),x=Object.assign(({open:e,onClose:t,size:a,className:o,children:s,preventScroll:d=!0,closeOnEscape:i=!0,closeOnOutsideClick:c=!0,animation:x,...f})=>{let b=(0,n.useRef)(null),h=(0,n.useId)(),v=`dialog-${h}`,w=`dialog-title-${h}`,j=`dialog-description-${h}`,{lockScroll:k,unlockScroll:N}=(0,u.A)(),[C,U]=(0,n.useState)(!1);(0,n.useEffect)(()=>(U(!0),()=>U(!1)),[]),(0,n.useEffect)(()=>{e&&d?k():N()});let S=(0,n.useMemo)(()=>({duration:400,backdropDuration:500,mount:"opacity-100 scale-100",unmount:"opacity-0 scale-115",backdropMount:"opacity-100 backdrop-blur-sm",backdropUnmount:"opacity-0 backdrop-blur-none"}),[]),$=(0,n.useMemo)(()=>({...S,...x}),[x,S]),z=(0,n.useCallback)(e=>{"Escape"===e.key&&i&&(e.preventDefault(),t())},[i,t]),E=(0,n.useCallback)(e=>{b.current&&b.current&&!b.current.contains(e.target)&&c&&t()},[c,t]);(0,n.useEffect)(()=>(e?(document.addEventListener("keydown",z),document.addEventListener("mousedown",E)):(document.removeEventListener("keydown",z),document.removeEventListener("mousedown",E)),()=>{document.removeEventListener("keydown",z),document.removeEventListener("mousedown",E)}),[e,z,E]);let I=(0,n.useMemo)(()=>({open:e,onClose:t,dialogId:v,titleId:w,descriptionId:j}),[e,t,v,w,j]);return C?(0,m.createPortal)((0,r.jsxs)(l.Provider,{value:I,children:[(0,r.jsx)(p.A,{show:e,duration:$.backdropDuration,mount:$.backdropMount,unmount:$.backdropUnmount,className:g(),children:(0,r.jsx)("div",{className:"w-full h-full","aria-hidden":"true"})}),(0,r.jsx)(p.A,{show:e,duration:$.duration,mount:$.mount,unmount:$.unmount,className:"fixed inset-0 z-50 flex items-center justify-center",children:(0,r.jsx)("div",{ref:b,role:"dialog","aria-modal":"true","aria-labelledby":w,"aria-describedby":j,id:v,className:y({size:a,className:o}),tabIndex:-1,...f,children:s})})]}),document.body):null},{Header:({className:e,children:t,...a})=>{let{titleId:n}=s();return(0,r.jsx)("div",{...a,className:c({className:e}),id:n,children:t})},Body:({divider:e,className:t,children:a,...n})=>{let{descriptionId:o}=s();return(0,r.jsx)("div",{...n,className:d({className:t,divider:e}),id:o,children:a})},Footer:({className:e,children:t,...a})=>(0,r.jsx)("div",{...a,className:i({className:e}),children:t})})},59001:(e,t,a)=>{a.d(t,{M:()=>n});var r=a(43210);let n=(e,t)=>{let[a,n]=(0,r.useState)(()=>{try{return t}catch(e){return console.error(e),t}});return(0,r.useEffect)(()=>{window.localStorage.setItem(e,JSON.stringify(a))},[e,a]),[a,t=>{try{let r=t instanceof Function?t(a):t;n(r),window.localStorage.setItem(e,JSON.stringify(r))}catch(e){console.error(e)}}]}},67419:(e,t,a)=>{a.d(t,{Q:()=>n});var r=a(6475);let n=(0,r.createServerReference)("400df766daf510d6a11795d882b1cd8e56931c2b3d",r.callServer,void 0,r.findSourceMapURL,"uploadFile")},76373:(e,t,a)=>{a.d(t,{dj:()=>r.useToast}),a(46093);var r=a(24399);a(29339)},85174:(e,t,a)=>{a.d(t,{v:()=>i});var r=a(60687),n=a(30474);let o=(0,a(81990).tv)({base:"relative inline-block object-cover object-center rounded-lg",variants:{bordered:{true:"border-2"},shadow:{true:"shadow-md"},variant:{circular:"rounded-full",square:"rounded-none"},size:{xs:"size-6",sm:"size-8",md:"size-10",lg:"size-12",xl:"size-[58px]",xxl:"size-[110px]"},boderColor:{default:"border-gray-600/20",success:"border-green-600/20",error:"border-red-600/20",info:"border-blue-600/20"}},defaultVariants:{shadow:!0,size:"md",variant:"circular",boderColor:"default"}}),l=({variant:e,size:t,className:a,boderColor:l,bordered:s,shadow:d,...i})=>{let c=o({variant:e,size:t,className:a,bordered:s,boderColor:l,shadow:d});return(0,r.jsx)(n.default,{...i,alt:i.alt,className:c})};var s=a(7766),d=a(57800);function i({s3Key:e,className:t,placeholderIcon:a}){return console.log(e),e?(0,r.jsx)(l,{src:`/api/s3-image/${e}`,alt:"company logo",width:400,height:400,className:t,loading:"lazy",style:{objectFit:"cover"}}):(0,r.jsx)("div",{className:(0,s.A)("flex-shrink-0 size-10 bg-gray-600/10 rounded-full flex items-center justify-center",t),children:a??(0,r.jsx)(d.A,{className:"h-5 w-5 text-muted"})})}}};